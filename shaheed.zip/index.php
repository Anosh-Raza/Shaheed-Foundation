<?php 
$page_title = "Home - Shaheed Foundation Hospital";
include "includes/header.php"; 
?>

<!-- Hero Section -->
<section class="hero">
    <div class="hero-slider">

        <div class="slide active">
            <img src="assets/images/banner1.jpeg" alt="Hospital Front View">
            <div class="slide-content">
                <h1>Welcome to Shaheed Foundation Hospital</h1>
                <p>Providing affordable healthcare with compassion and dignity.</p>
                <a href="about.php" class="btn-hero">Learn More</a>
            </div>
        </div>

        <div class="slide">
            <img src="assets/images/banner2.jpeg" alt="Doctors Team">
            <div class="slide-content">
                <h1>Our Expert Medical Team</h1>
                <p>Dedicated doctors and specialists serving the community.</p>
                <a href="services.php" class="btn-hero">Our Services</a>
            </div>
        </div>


        <div class="slide">
            <img src="assets/images/banner1.jpeg" alt="Hospital Front View">
            <div class="slide-content">
                <h1>Welcome to Shaheed Foundation Hospital</h1>
                <p>Providing affordable healthcare with compassion and dignity.</p>
                <a href="about.php" class="btn-hero">Learn More</a>
            </div>
        </div>

    </div>

    <!-- Slider controls -->
    <div class="slider-controls">
        <span class="prev"><i class="fa-solid fa-chevron-left"></i></span>
        <span class="next"><i class="fa-solid fa-chevron-right"></i></span>
    </div>

    <!-- Dots -->
    <div class="slider-dots"></div>
</section>

<!-- Info Section -->
<section class="info-section">
    <div class="container">
        <h5 class="subheading">Our Mission</h5>
        <h2 class="main-heading">Delivering Compassionate Healthcare to Everyone</h2>
        <p class="section-text">
            Shaheed Foundation Hospital is dedicated to providing affordable and accessible medical
            care to all individuals in need. Our mission is to bridge the healthcare gap in underserved
            communities by offering modern facilities, professional expertise, and a compassionate
            approach. Every patient matters — and every life counts.
        </p>
    </div>
</section>
<!-- Info Section End-->

<section class="gallery-content-section">
  <div class="gallery-content-container container">

    <!-- Left Column: Stacked Gallery -->
    <div class="gallery-column">
      <div class="stacked-container">
        <img src="assets/images/gallery1.jpg" alt="Hospital 1">
        <img src="assets/images/gallery2.jpg" alt="Hospital 2">
        <img src="assets/images/gallery3.jpg" alt="Hospital 3">
        <img src="assets/images/gallery4.jpg" alt="Hospital 4">
        <img src="assets/images/gallery5.jpg" alt="Hospital 5">
      </div>
    </div>

    <!-- Right Column: Text & CTA -->
    <div class="content-column">
      <h2 class="section-heading">Dedicated to Exceptional Healthcare</h2>
      <p class="section-description">
        At Shaheed Foundation Hospital, we’re committed to providing advanced healthcare
        services with compassion and expertise. Our facilities are equipped with modern
        technology and a team of experienced medical professionals ready to care for you.
      </p>
      <a href="/shaheed/contact.php" class="cta-btn">Book an Appointment</a>
    </div>

  </div>
</section>



<!-- Youtube Section -->
<section class="talk-health">
  <div class="container">
    <h3 class="subheading">Let's Talk Health</h3>
    <p class="description">
      Learn from our experts as they discuss important health issues affecting our local communities.
    </p>

    <div class="video-grid">
      <!-- Video 1 -->
      <a href="https://www.youtube.com/watch?si=au-8A-5Ikx10qraE&v=-KSRYccL8R4&feature=youtu.be" target="_blank" class="video-item" data-video-id="-KSRYccL8R4">
        <div class="thumbnail">
          <img alt="Mental Health Awareness">
          <div class="overlay">
            <i class="fa-brands fa-youtube"></i>
            <span>Watch on YouTube</span>
          </div>
        </div>
      </a>

      <!-- Video 2 -->
      <a href="https://www.youtube.com/watch?si=au-8A-5Ikx10qraE&v=-KSRYccL8R4&feature=youtu.be" target="_blank" class="video-item" data-video-id="-KSRYccL8R4">
        <div class="thumbnail">
          <img alt="Healthy Living Tips">
          <div class="overlay">
            <i class="fa-brands fa-youtube"></i>
            <span>Watch on YouTube</span>
          </div>
        </div>
      </a>

      <!-- Video 3 -->
      <a href="https://www.youtube.com/watch?si=au-8A-5Ikx10qraE&v=-KSRYccL8R4&feature=youtu.be" target="_blank" class="video-item" data-video-id="-KSRYccL8R4">
        <div class="thumbnail">
          <img alt="Exercise for Health">
          <div class="overlay">
            <i class="fa-brands fa-youtube"></i>
            <span>Watch on YouTube</span>
          </div>
        </div>
      </a>
    </div>
  </div>
</section>

<script>
  // Automatically set YouTube thumbnail for each video-item
  document.querySelectorAll('.video-item').forEach(item => {
    const videoId = item.getAttribute('data-video-id');
    const img = item.querySelector('img');
    img.src = `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;
  });
</script>


<!-- Spedicalities Section -->
<section class="specialties-section">
    <div class="container">
        <h2 class="section-title">Our Specialties</h2>

        <div class="specialties-grid">
            <div class="specialty-box">
                <img src="assets/images/Pediatrician.png" alt="Obstetrics">
                <p>Pediatrician</p>
            </div>
            <div class="specialty-box">
                <img src="assets/images/orthopedic.png" alt="General Surgery">
                <p>Orthopedic</p>
            </div>
            <div class="specialty-box">
                <img src="assets/images/OPD.png" alt="ENT">
                <p>OPD</p>
            </div>
            <div class="specialty-box">
                <img src="assets/images/general_opd.png" alt="Nephrology">
                <p>General OPD</p>
            </div>
            <div class="specialty-box">
                <img src="assets/images/ent.png" alt="Dentistry">
                <p>END</p>
            </div>
            <div class="specialty-box">
                <img src="assets/images/endocrinologist.png" alt="Internal Medicine">
                <p>Endocrinologist</p>
            </div>
        </div>
    </div>
</section>

<!-- Specialities Section End-->


<!-- News Section -->
<section class="news-section">
    <div class="container">
        <h2 class="section-heading">News & Events</h2>

        <div class="news-grid">
            <!-- News Item 1 -->
            <div class="news-item">
                <div class="news-thumb">
                    <img src="https://www.shaheedfoundation.org/assets/images/hospital_advert.jpg" alt="News 1">
                    <span class="badge">NEWS & EVENTS</span>
                </div>
                <div class="news-content">
                    <h4>SHIFA Organizes The 1st Local Pediatric Dysphagia Support Group</h4>
                    <p class="date">May 23, 2023</p>
                </div>
            </div>

            <!-- News Item 2 -->
            <div class="news-item">
                <div class="news-thumb">
                    <img src="https://www.shaheedfoundation.org/assets/images/hospital_advert.jpg" alt="News 2">
                    <span class="badge">NEWS & EVENTS</span>
                </div>
                <div class="news-content">
                    <h4>Congratulations. Shifa Surgery Team and Dr. Ghulam Siddiq Achieved the Milestone of Completing
                        1000 Bariatric Surgeries</h4>
                    <p class="date">April 1, 2024</p>
                </div>
            </div>

            <!-- News Item 3 -->
            <div class="news-item">
                <div class="news-thumb">
                    <img src="https://www.shaheedfoundation.org/assets/images/hospital_advert.jpg" alt="News 3">
                    <span class="badge">NEWS & EVENTS</span>
                </div>
                <div class="news-content">
                    <h4>Over 660 Graduates Awarded Degrees at 10th Convocation of Shifa Tameer-e-Millat University
                        (STMU)</h4>
                    <p class="date">April 1, 2024</p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- News Section End-->

<section class="testimonial-section">
    <div class="container">
        <div class="section-header">
            <h2>What Our Patients Say</h2>
            <p>
                We take pride in providing the best healthcare experience for every patient.
                Here’s what some of our patients have to say about their journey with us.
            </p>
        </div>

        <div class="swiper testimonial-slider">
            <div class="swiper-wrapper">
                <div class="swiper-slide testimonial-card">
                    <div class="testimonial-content">
                        <img src="https://i.pravatar.cc/100?img=1" alt="Client 1" class="client-img">
                        <p class="testimonial-text">
                            “The doctors and staff were exceptionally professional. My surgery went smoothly,
                            and the post-op care was outstanding!”
                        </p>
                        <h4 class="client-name">Sarah Khan</h4>
                        <span class="client-company">Marketing Manager, ABC Ltd.</span>
                    </div>
                </div>

                <div class="swiper-slide testimonial-card">
                    <div class="testimonial-content">
                        <img src="https://i.pravatar.cc/100?img=2" alt="Client 2" class="client-img">
                        <p class="testimonial-text">
                            “MMI Hospital made me feel at home. The environment was clean, and
                            the staff treated me with utmost respect and care.”
                        </p>
                        <h4 class="client-name">Ali Raza</h4>
                        <span class="client-company">Entrepreneur</span>
                    </div>
                </div>

                <div class="swiper-slide testimonial-card">
                    <div class="testimonial-content">
                        <img src="https://i.pravatar.cc/100?img=3" alt="Client 3" class="client-img">
                        <p class="testimonial-text">
                            “From diagnosis to discharge, every step was handled with precision and empathy.
                            I’m truly grateful for the excellent care.”
                        </p>
                        <h4 class="client-name">Dr. Amna Siddiqui</h4>
                        <span class="client-company">Lecturer, Health Sciences</span>
                    </div>
                </div>
            </div>

            <div class="swiper-pagination"></div>
            <div class="swiper-button-prev"></div>
            <div class="swiper-button-next"></div>
        </div>
    </div>
</section>

<style>
.testimonial-section {
    background-color: var(--light);
    padding: 80px 20px;
    font-family: var(--font-family);
}

.section-header {
    text-align: center;
    max-width: 700px;
    margin: 0 auto 50px;
}

.section-header h2 {
    font-size: 2.2rem;
    color: var(--primary-color);
    font-weight: 700;
    margin-bottom: 15px;
}

.section-header p {
    color: #555;
    font-size: 1rem;
    line-height: 1.7;
}

.testimonial-slider {
    position: relative;
    width: 100%;
    overflow: hidden;
    display: flex;
    justify-content: center;
    align-items: center;
}

.testimonial-card {
    display: flex;
    justify-content: center;
}

.testimonial-content {
    background: var(--white);
    padding: 40px 30px;
    border-radius: 15px;
    max-width: 600px;
    text-align: center;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.testimonial-content:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
}

.client-img {
    width: 80px;
    height: 80px;
    border-radius: 50%;
    object-fit: cover;
    margin-bottom: 20px;
    border: 4px solid var(--primary-color);
}

.testimonial-text {
    font-style: italic;
    color: #333;
    font-size: 1rem;
    margin-bottom: 25px;
    line-height: 1.7;
}

.client-name {
    color: var(--primary-color);
    font-weight: 600;
    font-size: 1.1rem;
}

.client-company {
    display: block;
    color: #666;
    font-size: 0.95rem;
}

.swiper-button-next,
.swiper-button-prev {
    color: var(--primary-color);
    background: var(--white);
    border: 2px solid var(--primary-color);
    border-radius: 50%;
    width: 35px;
    height: 35px;
    display: flex;
    justify-content: center;
    align-items: center;
    top: 50%;
    transform: translateY(-50%);
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
}

.swiper-button-prev {
    left: 10%;
}

.swiper-button-next {
    right: 10%;
}

.swiper-button-next:after,
.swiper-button-prev:after {
    font-size: 18px
}

.swiper-pagination-bullet {
    background: var(--primary-color);
}

@media (max-width: 768px) {
    .testimonial-content {
        padding: 30px 20px;
    }

    .section-header h2 {
        font-size: 1.8rem;
    }

    .swiper-button-prev {
        left: 2%;
    }

    .swiper-button-next {
        right: 2%;
    }
}
</style>

<script>
var swiper = new Swiper(".testimonial-slider", {
    loop: true,
    autoplay: {
        delay: 4000,
        disableOnInteraction: false,
    },
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },
});
</script>



<!--Newsletter Donater Section-->
<section class="newsletter-donate">
    <div class="container">
        <div class="content-wrapper">
            <!-- Left Content -->
            <div class="newsletter-content">
                <h2 class="heading">Stay Connected With Us</h2>
                <p class="text">
                    Subscribe to our newsletter and receive updates about our medical programs,
                    health awareness events, and community initiatives.
                </p>
                <form class="newsletter-form">
                    <input type="email" placeholder="Enter your email address" required>
                    <button type="submit" class="btn-subscribe">Subscribe</button>
                </form>
            </div>

            <!-- Right Content -->
            <div class="donate-box">
                <h3>Your Support Makes a Difference</h3>
                <p>
                    Every donation helps us improve healthcare facilities and serve those in need.
                </p>
                <a href="donate.php" class="news btn-donate">Donate Now</a>
            </div>
        </div>
    </div>
</section>
<!--Newsletter Donater Section End-->


<?php include "includes/footer.php"; ?>