<?php 
$page_title = "About - Shaheed Foundation Hospital";
include "includes/header.php"; 
?>
<h1>About Us</h1>
<p>Our mission is to provide high-quality, affordable healthcare.</p>
<?php include "includes/footer.php"; ?>
